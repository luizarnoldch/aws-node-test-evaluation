import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
export declare function createLocalDynamoDBStreamTable(client: DynamoDBClient, tableName: string): Promise<void>;
export declare function deleteLocalDynamoDBStreamTable(client: DynamoDBClient, tableName: string): Promise<void>;

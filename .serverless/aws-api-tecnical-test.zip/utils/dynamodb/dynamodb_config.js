"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.localDynamoDBClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
function createLocalDynamoDBClient() {
    return new client_dynamodb_1.DynamoDBClient({
        endpoint: "http://localhost:8000",
        region: "local-env",
        credentials: {
            accessKeyId: "fakeMyKeyId",
            secretAccessKey: "fakeSecretAccessKey"
        }
    });
}
console.log("Conected to DynamoDB locally");
exports.localDynamoDBClient = createLocalDynamoDBClient();
//# sourceMappingURL=dynamodb_config.js.map
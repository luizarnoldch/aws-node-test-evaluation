"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteLocalDynamoDBStreamTable = exports.createLocalDynamoDBStreamTable = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_dynamodb_2 = require("@aws-sdk/client-dynamodb");
async function createLocalDynamoDBStreamTable(client, tableName) {
    const createTableInput = {
        AttributeDefinitions: [
            {
                AttributeName: "ID",
                AttributeType: "S",
            },
        ],
        KeySchema: [
            {
                AttributeName: "ID",
                KeyType: "HASH",
            },
        ],
        TableName: tableName,
        BillingMode: "PAY_PER_REQUEST",
    };
    try {
        await client.send(new client_dynamodb_1.CreateTableCommand(createTableInput));
        console.log(`Table ${tableName} created successfully`);
    }
    catch (error) {
        console.error(`Error creating table ${tableName}`, error);
        throw error;
    }
}
exports.createLocalDynamoDBStreamTable = createLocalDynamoDBStreamTable;
async function deleteLocalDynamoDBStreamTable(client, tableName) {
    try {
        await client.send(new client_dynamodb_2.DescribeTableCommand({ TableName: tableName }));
        await client.send(new client_dynamodb_2.DeleteTableCommand({ TableName: tableName }));
        console.log(`Table ${tableName} deleted successfully`);
    }
    catch (error) {
        if (error.name === 'ResourceNotFoundException') {
            console.error(`Table ${tableName} does not exist, no need to delete`);
        }
        else {
            throw error;
        }
    }
}
exports.deleteLocalDynamoDBStreamTable = deleteLocalDynamoDBStreamTable;
//# sourceMappingURL=dynamodb_init.js.map
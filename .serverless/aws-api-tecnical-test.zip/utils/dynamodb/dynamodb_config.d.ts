import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
export declare const localDynamoDBClient: DynamoDBClient;

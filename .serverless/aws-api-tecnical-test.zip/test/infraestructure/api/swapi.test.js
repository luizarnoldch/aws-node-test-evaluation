"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const swapi_1 = require("./../../../src/infrastructure/api/swapi");
const jest_fetch_mock_1 = require("jest-fetch-mock");
(0, jest_fetch_mock_1.enableFetchMocks)();
beforeEach(() => {
    fetchMock.resetMocks();
});
const API_BASE_URL = process.env.SWAPI_BASE_URL;
const PEOPLE_SWAPI = API_BASE_URL ? API_BASE_URL + "people/" : undefined;
test('GetPeopleByIdFromSwapi returns data for ID 1', async () => {
    const mockData = {
        "name": "Luke Skywalker",
        "height": "172",
        "mass": "77",
        "hair_color": "blond",
        "skin_color": "fair",
        "eye_color": "blue",
        "birth_year": "19BBY",
        "gender": "male",
        "homeworld": "https://swapi.py4e.com/api/planets/1/",
        "films": [
            "https://swapi.py4e.com/api/films/1/",
            "https://swapi.py4e.com/api/films/2/",
            "https://swapi.py4e.com/api/films/3/",
            "https://swapi.py4e.com/api/films/6/",
            "https://swapi.py4e.com/api/films/7/"
        ],
        "species": [
            "https://swapi.py4e.com/api/species/1/"
        ],
        "vehicles": [
            "https://swapi.py4e.com/api/vehicles/14/",
            "https://swapi.py4e.com/api/vehicles/30/"
        ],
        "starships": [
            "https://swapi.py4e.com/api/starships/12/",
            "https://swapi.py4e.com/api/starships/22/"
        ],
        "created": "2014-12-09T13:50:51.644000Z",
        "edited": "2014-12-20T21:17:56.891000Z",
        "url": "https://swapi.py4e.com/api/people/1/"
    };
    fetchMock.mockResponseOnce(JSON.stringify(mockData));
    const result = await (0, swapi_1.GetPeopleByIdFromSwapi)(1);
    expect(mockData.name).toEqual("Luke Skywalker");
    expect(result).toEqual(mockData);
    expect(fetchMock.mock.calls.length).toEqual(1);
    expect(fetchMock.mock.calls[0][0]).toEqual(`${PEOPLE_SWAPI}1/`);
    expect("https://swapi.py4e.com/api/people/1").toEqual(`${PEOPLE_SWAPI}1`);
});
//# sourceMappingURL=swapi.test.js.map
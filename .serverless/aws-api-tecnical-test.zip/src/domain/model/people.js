"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isPeople = exports.ConvertPeopleToPersona = void 0;
const ConvertPeopleToPersona = (people) => {
    return {
        ID: people.ID,
        nombre: people.name,
        altura: people.height,
        masa: people.mass,
        colorDeCabello: people.hair_color,
        colorDePiel: people.skin_color,
        colorDeOjos: people.eye_color,
        anioDeNacimiento: people.birth_year,
        genero: people.gender === 'male' ? 'masculino' : people.gender === 'female' ? 'femenino' : people.gender,
        ciudadNatal: people.homeworld,
        peliculas: people.films,
        especies: people.species,
        vehiculos: people.vehicles,
        navesEstelares: people.starships,
        creado: people.created,
        editado: people.edited,
        url: people.url
    };
};
exports.ConvertPeopleToPersona = ConvertPeopleToPersona;
function isPeople(object) {
    const requiredStringFields = [
        'name', 'height', 'mass', 'hair_color', 'skin_color',
        'eye_color', 'birth_year', 'gender', 'homeworld',
        'created', 'edited', 'url'
    ];
    const requiredArrayFields = ['films', 'species', 'vehicles', 'starships'];
    const hasAllStringFields = requiredStringFields.every(field => object.hasOwnProperty(field) && typeof object[field] === 'string');
    const hasAllArrayFields = requiredArrayFields.every(field => object.hasOwnProperty(field) && Array.isArray(object[field]));
    return hasAllStringFields && hasAllArrayFields;
}
exports.isPeople = isPeople;
//# sourceMappingURL=people.js.map
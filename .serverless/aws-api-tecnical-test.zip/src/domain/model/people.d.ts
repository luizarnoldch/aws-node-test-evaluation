export interface People {
    ID?: string;
    name: string;
    height: string;
    mass: string;
    hair_color: string;
    skin_color: string;
    eye_color: string;
    birth_year: string;
    gender: string;
    homeworld: string;
    films: string[];
    species: string[];
    vehicles: string[];
    starships: string[];
    created: string;
    edited: string;
    url: string;
}
export interface Persona {
    ID?: string;
    nombre: string;
    altura: string;
    masa: string;
    colorDeCabello: string;
    colorDePiel: string;
    colorDeOjos: string;
    anioDeNacimiento: string;
    genero: string;
    ciudadNatal: string;
    peliculas: string[];
    especies: string[];
    vehiculos: string[];
    navesEstelares: string[];
    creado: string;
    editado: string;
    url: string;
}
export declare const ConvertPeopleToPersona: (people: People) => Persona;
export declare function isPeople(object: any): object is People;

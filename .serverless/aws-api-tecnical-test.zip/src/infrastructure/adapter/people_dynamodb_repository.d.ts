import { PeopleRepository } from "./../../domain/repostiory/people_repository";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { Persona } from "../../domain/model/people";
export declare class PeopleDynamoDBRepository implements PeopleRepository {
    private ddbDocClient;
    private tableName;
    constructor(ddbClient: DynamoDBClient, tableName: string | undefined);
    GetPeopleFromSWAPI(id: number): Promise<Persona | unknown>;
    PostPeopleToDynamoDB(persona: Persona): Promise<Persona | unknown>;
}

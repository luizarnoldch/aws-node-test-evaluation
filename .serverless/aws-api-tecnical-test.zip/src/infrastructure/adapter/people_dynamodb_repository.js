"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PeopleDynamoDBRepository = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const people_1 = require("../../domain/model/people");
const swapi_1 = require("./../api/swapi");
const crypto_1 = require("crypto");
class PeopleDynamoDBRepository {
    constructor(ddbClient, tableName) {
        this.ddbDocClient = lib_dynamodb_1.DynamoDBDocumentClient.from(ddbClient);
        this.tableName = tableName;
    }
    async GetPeopleFromSWAPI(id) {
        try {
            const people = await (0, swapi_1.GetPeopleByIdFromSwapi)(id);
            if ((0, people_1.isPeople)(people)) {
                const persona = (0, people_1.ConvertPeopleToPersona)(people);
                return persona;
            }
            else {
                throw new Error("El objeto recibido no es de tipo People");
            }
        }
        catch (error) {
            return error;
        }
    }
    async PostPeopleToDynamoDB(persona) {
        const id = (0, crypto_1.randomUUID)();
        persona.ID = id;
        const params = {
            TableName: this.tableName,
            Item: persona,
        };
        await this.ddbDocClient.send(new lib_dynamodb_1.PutCommand(params));
        try {
            await this.ddbDocClient.send(new lib_dynamodb_1.PutCommand(params));
        }
        catch (error) {
            return error;
        }
        return persona;
    }
}
exports.PeopleDynamoDBRepository = PeopleDynamoDBRepository;
//# sourceMappingURL=people_dynamodb_repository.js.map
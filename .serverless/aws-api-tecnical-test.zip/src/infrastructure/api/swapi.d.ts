import { People } from "./../../domain/model/people";
export declare const GetPeopleByIdFromSwapi: (id: number) => Promise<People | unknown>;

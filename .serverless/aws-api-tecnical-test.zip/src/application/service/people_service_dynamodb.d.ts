import { Persona } from "../../domain/model/people";
import { PeopleRepository } from "../../domain/repostiory/people_repository";
import { PeopleService } from "./people_service";
export declare class PeopleServiceDynamoDB implements PeopleService {
    private repository;
    constructor(repository: PeopleRepository);
    GetPeopleFromSWAPI(id: number): Promise<Persona | unknown>;
    PostPeopleToDynamoDB(persona: Persona): Promise<Persona | unknown>;
}

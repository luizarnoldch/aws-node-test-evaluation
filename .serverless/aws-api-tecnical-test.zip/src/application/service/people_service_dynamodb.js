"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PeopleServiceDynamoDB = void 0;
class PeopleServiceDynamoDB {
    constructor(repository) {
        this.repository = repository;
    }
    async GetPeopleFromSWAPI(id) {
        return this.repository.GetPeopleFromSWAPI(id);
    }
    async PostPeopleToDynamoDB(persona) {
        return this.repository.PostPeopleToDynamoDB(persona);
    }
}
exports.PeopleServiceDynamoDB = PeopleServiceDynamoDB;
//# sourceMappingURL=people_service_dynamodb.js.map
import { Request, Response } from "express";
export declare const GetPeopleFromSWAPI: (req: Request, res: Response) => Promise<void>;
export declare const PostPeopleToDynamoDB: (req: Request, res: Response) => Promise<void>;

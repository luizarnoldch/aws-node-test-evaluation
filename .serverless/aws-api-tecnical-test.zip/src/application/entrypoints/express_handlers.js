"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostPeopleToDynamoDB = exports.GetPeopleFromSWAPI = void 0;
const dotenv = __importStar(require("dotenv"));
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const people_service_dynamodb_1 = require("../service/people_service_dynamodb");
const people_dynamodb_repository_1 = require("../../infrastructure/adapter/people_dynamodb_repository");
const dynamodb_config_1 = require("../../../utils/dynamodb/dynamodb_config");
dotenv.config();
const PEOPLE_TABLE = process.env.PEOPLE_TABLE || process.env.TEST_PEOPLE_TABLE;
const dynamoClient = process.env.PEOPLE_TABLE
    ? new client_dynamodb_1.DynamoDBClient()
    : dynamodb_config_1.localDynamoDBClient;
const peopleRepository = new people_dynamodb_repository_1.PeopleDynamoDBRepository(dynamoClient, PEOPLE_TABLE);
const peopleService = new people_service_dynamodb_1.PeopleServiceDynamoDB(peopleRepository);
const GetPeopleFromSWAPI = async (req, res) => {
    const { id } = req.params;
    const idReq = parseInt(id, 10);
    try {
        const response = await peopleService.GetPeopleFromSWAPI(idReq);
        res.json(response);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
};
exports.GetPeopleFromSWAPI = GetPeopleFromSWAPI;
const PostPeopleToDynamoDB = async (req, res) => {
    try {
        const newPerson = await peopleService.PostPeopleToDynamoDB(req.body);
        res.status(201).json(newPerson);
    }
    catch (error) {
        res.status(500).json({ error: error.message });
    }
};
exports.PostPeopleToDynamoDB = PostPeopleToDynamoDB;
//# sourceMappingURL=express_handlers.js.map
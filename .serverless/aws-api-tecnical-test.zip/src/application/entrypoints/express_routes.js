"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const express_handlers_1 = require("./express_handlers");
const router = (0, express_1.Router)();
router.get("/people/:id", express_handlers_1.GetPeopleFromSWAPI);
router.post("/people", express_handlers_1.PostPeopleToDynamoDB);
exports.default = router;
//# sourceMappingURL=express_routes.js.map